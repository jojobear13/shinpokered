This .avery file is a saved design for Avery custom label sheets at:
https://www.avery.com/custom-printing/labels/calculator/sheets

Settings are:
- Sheet labels
- Rectangle
- Rounded corners
- Custom rectangle size of 1.456 x 1.653 inches
- Glossy white paper

Choose "Start Designing".
Then choose "Create".
Then choose "Create your own design".
In the top-right corner choose "Open".
Then choose to open a .avery file.
Select the .avery file in this folder to load the saved design.